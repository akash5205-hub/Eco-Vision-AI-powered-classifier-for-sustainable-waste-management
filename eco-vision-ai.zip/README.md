# Eco-Vision-AI

End-to-end waste classification project.

## Quick start
1. Arrange dataset like:
   dataset/
     train/
       plastic/
       paper/
       metal/
       organic/
     val/
       ...
2. Install dependencies: `pip install -r requirements.txt`
3. Train: `python train.py --data-dir dataset --epochs 20 --batch-size 32`
4. Inference: `python inference.py --model checkpoints/best.pth --image path/to/img.jpg`
5. Run demo: `python app.py` and open http://127.0.0.1:5000
