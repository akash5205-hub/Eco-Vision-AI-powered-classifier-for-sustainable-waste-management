from flask import Flask, request, render_template_string, send_from_directory
import os
from inference import load_model, predict_image
from dataset import get_transforms
import torch

app = Flask(__name__)
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
MODEL_PATH = 'checkpoints/best.pth'
model, class_to_idx = load_model(MODEL_PATH, DEVICE)
idx_to_class = {v:k for k,v in class_to_idx.items()}
TF = get_transforms(224, train=False)

HTML = '''
<!doctype html>
<title>Eco-Vision-AI Demo</title>
<h1>Upload an image of waste</h1>
<form method=post enctype=multipart/form-data>
  <input type=file name=file>
  <input type=submit value=Upload>
</form>
{% if result %}
  <h2>Prediction: {{result[0]}} ({{(result[1]*100)|round(2)}}%)</h2>
  <img src="{{url}}" width=300>
{% endif %}
'''

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    img_url = None
    if request.method == 'POST':
        f = request.files['file']
        if f:
            path = os.path.join('uploads', f.filename)
            os.makedirs('uploads', exist_ok=True)
            f.save(path)
            label, conf = predict_image(model, path, TF, DEVICE, idx_to_class)
            result = (label, conf)
            img_url = '/uploads/' + f.filename
    return render_template_string(HTML, result=result, url=img_url)

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory('uploads', filename)

if __name__ == '__main__':
    app.run(debug=True)
