import os
from PIL import Image
from torchvision import transforms
from torch.utils.data import Dataset

class WasteDataset(Dataset):
    """Simple folder-structured dataset. Expects:
    root/class_x/*.jpg
    root/class_y/*.jpg
    """
    def __init__(self, root, split='train', transform=None):
        self.root = os.path.join(root, split)
        self.transform = transform
        self.samples = []
        classes = sorted([d for d in os.listdir(self.root) if os.path.isdir(os.path.join(self.root, d))])
        self.class_to_idx = {c:i for i,c in enumerate(classes)}
        for c in classes:
            p = os.path.join(self.root, c)
            for fname in os.listdir(p):
                if fname.lower().endswith(('.jpg','.jpeg','.png')):
                    self.samples.append((os.path.join(p, fname), self.class_to_idx[c]))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        img = Image.open(path).convert('RGB')
        if self.transform:
            img = self.transform(img)
        return img, label

def get_transforms(image_size=224, train=True):
    if train:
        return transforms.Compose([
            transforms.RandomResizedCrop(image_size, scale=(0.6,1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(15),
            transforms.ColorJitter(0.2,0.2,0.2,0.02),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225])
        ])
    else:
        return transforms.Compose([
            transforms.Resize(int(image_size*256/224)),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225])
        ])
