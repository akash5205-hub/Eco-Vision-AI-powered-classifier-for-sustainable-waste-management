import argparse
import torch
from torch.utils.data import DataLoader
from dataset import WasteDataset, get_transforms
from model import WasteClassifier
from sklearn.metrics import classification_report, confusion_matrix
import numpy as np

def load_checkpoint(path, device):
    ckpt = torch.load(path, map_location=device)
    return ckpt

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', required=True)
    parser.add_argument('--model', required=True)
    parser.add_argument('--image-size', type=int, default=224)
    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    val_tf = get_transforms(args.image_size, train=False)
    val_ds = WasteDataset(args.data_dir, split='val', transform=val_tf)
    loader = DataLoader(val_ds, batch_size=32, shuffle=False, num_workers=4)

    ckpt = load_checkpoint(args.model, device)
    num_classes = len(ckpt['class_to_idx'])
    model = WasteClassifier(num_classes=num_classes, pretrained=False).to(device)
    model.load_state_dict(ckpt['model_state'])
    model.eval()

    all_preds = []
    all_targets = []
    with torch.no_grad():
        for imgs, labels in loader:
            imgs = imgs.to(device)
            outputs = model(imgs)
            preds = outputs.argmax(dim=1).cpu().numpy()
            all_preds.extend(preds.tolist())
            all_targets.extend(labels.numpy().tolist())

    idx_to_class = {v:k for k,v in ckpt['class_to_idx'].items()}
    print(classification_report(all_targets, all_preds, target_names=[idx_to_class[i] for i in range(len(idx_to_class))]))
    print('Confusion matrix:')
    print(confusion_matrix(all_targets, all_preds))

if __name__ == '__main__':
    main()
