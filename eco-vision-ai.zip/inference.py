import argparse
import torch
from PIL import Image
from model import WasteClassifier
from dataset import get_transforms
import os

def load_model(path, device):
    ckpt = torch.load(path, map_location=device)
    num_classes = len(ckpt['class_to_idx'])
    model = WasteClassifier(num_classes=num_classes, pretrained=False).to(device)
    model.load_state_dict(ckpt['model_state'])
    model.eval()
    return model, ckpt['class_to_idx']

def predict_image(model, img_path, transform, device, idx_to_class):
    img = Image.open(img_path).convert('RGB')
    inp = transform(img).unsqueeze(0).to(device)
    with torch.no_grad():
        out = model(inp)
        prob = torch.softmax(out, dim=1)[0]
        pred = prob.argmax().item()
    return idx_to_class[pred], prob[pred].item()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True)
    parser.add_argument('--image', required=True)
    parser.add_argument('--image-size', type=int, default=224)
    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model, class_to_idx = load_model(args.model, device)
    idx_to_class = {v:k for k,v in class_to_idx.items()}
    tf = get_transforms(args.image_size, train=False)
    label, conf = predict_image(model, args.image, tf, device, idx_to_class)
    print(f'Predicted: {label} ({conf*100:.2f}%)')

if __name__ == '__main__':
    main()
