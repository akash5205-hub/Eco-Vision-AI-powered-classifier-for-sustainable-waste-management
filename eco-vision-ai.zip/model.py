import torch
import torch.nn as nn
from torchvision import models

class WasteClassifier(nn.Module):
    def __init__(self, num_classes, pretrained=True):
        super().__init__()
        # Use a lightweight model suitable for edge (MobileNetV3 Large) or EfficientNet
        backbone = models.mobilenet_v3_large(pretrained=pretrained)
        # Replace classifier
        try:
            in_features = backbone.classifier[0].in_features
        except Exception:
            # fallback for different torchvision versions
            in_features = backbone.classifier.in_features
        backbone.classifier = nn.Identity()
        self.backbone = backbone
        self.classifier = nn.Sequential(
            nn.Dropout(p=0.3),
            nn.Linear(in_features, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        # handle case where backbone outputs feature map
        if x.ndim == 4:
            x = x.mean(dim=[2,3])
        x = self.classifier(x)
        return x
