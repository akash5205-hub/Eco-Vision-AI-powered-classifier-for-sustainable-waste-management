import os
import argparse
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from tqdm import tqdm
from dataset import WasteDataset, get_transforms
from model import WasteClassifier
from utils import set_seed, accuracy

def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    running_acc = 0.0
    for imgs, labels in tqdm(loader, desc='train', leave=False):
        imgs = imgs.to(device)
        labels = labels.to(device)
        optimizer.zero_grad()
        outputs = model(imgs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * imgs.size(0)
        running_acc += accuracy(outputs, labels)[0] * imgs.size(0) / 100.0
    n = len(loader.dataset)
    return running_loss / n, running_acc / n

def validate(model, loader, criterion, device):
    model.eval()
    running_loss = 0.0
    running_acc = 0.0
    with torch.no_grad():
        for imgs, labels in tqdm(loader, desc='val', leave=False):
            imgs = imgs.to(device)
            labels = labels.to(device)
            outputs = model(imgs)
            loss = criterion(outputs, labels)
            running_loss += loss.item() * imgs.size(0)
            running_acc += accuracy(outputs, labels)[0] * imgs.size(0) / 100.0
    n = len(loader.dataset)
    return running_loss / n, running_acc / n

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', required=True)
    parser.add_argument('--epochs', type=int, default=12)
    parser.add_argument('--batch-size', type=int, default=32)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--image-size', type=int, default=224)
    parser.add_argument('--checkpoint-dir', default='checkpoints')
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()

    set_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    train_tf = get_transforms(args.image_size, train=True)
    val_tf = get_transforms(args.image_size, train=False)

    train_ds = WasteDataset(args.data_dir, split='train', transform=train_tf)
    val_ds = WasteDataset(args.data_dir, split='val', transform=val_tf)

    num_classes = len(train_ds.class_to_idx)
    print('Classes:', train_ds.class_to_idx)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=4)

    model = WasteClassifier(num_classes=num_classes, pretrained=True).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'max', patience=2, factor=0.5)

    os.makedirs(args.checkpoint_dir, exist_ok=True)
    best_acc = 0.0

    for epoch in range(1, args.epochs+1):
        print(f'Epoch {epoch}/{args.epochs}')
        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_loss, val_acc = validate(model, val_loader, criterion, device)
        scheduler.step(val_acc)
        print(f'Train Loss: {train_loss:.4f} Acc: {train_acc:.4f} | Val Loss: {val_loss:.4f} Acc: {val_acc:.4f}')

        # save
        ckpt = {
            'epoch': epoch,
            'model_state': model.state_dict(),
            'optimizer_state': optimizer.state_dict(),
            'class_to_idx': train_ds.class_to_idx
        }
        torch.save(ckpt, os.path.join(args.checkpoint_dir, f'epoch_{epoch}.pth'))
        if val_acc > best_acc:
            best_acc = val_acc
            torch.save(ckpt, os.path.join(args.checkpoint_dir, 'best.pth'))

if __name__ == '__main__':
    main()
